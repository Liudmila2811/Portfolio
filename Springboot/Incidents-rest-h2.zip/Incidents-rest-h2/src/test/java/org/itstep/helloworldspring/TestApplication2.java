package org.itstep.helloworldspring;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.HashSet;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestApplication2 {
    @Autowired
    private MockMvc mvc; // Mock объект - это объект специально для тестирования


    @Test // Выводим все даты
    @Order(1)
    public void dates() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/incident_reports")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(5)))
                .andExpect(jsonPath("$[0].date", Matchers.equalTo("2020-03-29")))
                .andExpect(jsonPath("$[0].type_id", Matchers.equalTo(1)));
    }

    @Test // Вывести одну дату по id
    @Order(2)
    public void getDatesById() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/incident_reports/{incident_id}",1)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.date", Matchers.equalTo("2020-03-29")))
                .andExpect(jsonPath("$.type_id", Matchers.equalTo(1)));
    }


    @ParameterizedTest // Создаем параметризованный тест
    @Order(3)
    @ValueSource(ints = {-1, 0, 1, 2, 3, 4, 5, Integer.MAX_VALUE})
    public void getDateById(int incident_id) throws Exception {
        ResultActions actions = mvc.perform
                (MockMvcRequestBuilders.get("/incident_reports/{incident_id}",incident_id).
                accept(MediaType.APPLICATION_JSON));
        actions
                .andExpect(status().isOk());
        switch (incident_id){
            case 1:
                actions
                        .andExpect(jsonPath("$.date", Matchers.equalTo("2020-03-29")));
                break;
            case 2:
                actions
                        .andExpect(jsonPath("$.date", Matchers.equalTo("2020-04-03")));
                break;
            case 3:
                actions
                        .andExpect(jsonPath("$.date", Matchers.equalTo("2021-05-25")));
                break;
            case 4:
                actions
                        .andExpect(jsonPath("$.date", Matchers.equalTo("2022-02-15")));
                break;
            case 5:
                actions
                        .andExpect(jsonPath("$.date", Matchers.equalTo("2022-03-27")));
                break;
            default:
                actions
                        .andExpect(content().string("null"));
        }
    }


    @Test
    @Order(4)
    public void postDate() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                        .post("/incident_reports")
                        .content(asJsonString(new IncidentReports
                                (6L, "2022-02-02", 5L)))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.incident_id", equalTo(6)))
                .andExpect(jsonPath("$.date", equalTo("2022-02-02")));
    }

     public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @Test
    @Order(5)
    public void putDate() throws Exception {
        mvc.perform(MockMvcRequestBuilders.put("/incident_reports/2")
                        .content(asJsonString
                                (new IncidentReports(2L, "2000-00-00", 2L)))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.date", Matchers.equalTo("2000-00-00")))
                .andExpect(jsonPath("$.type_id", Matchers.equalTo(2)));
    }

    @Test
    @Order(6)
    public void deleteDate() throws Exception
    {
        mvc.perform( MockMvcRequestBuilders.delete("/incident_reports/2") )
                .andExpect(status().isOk());
    }
}

