package org.itstep.helloworldspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;
import java.util.Optional;

@Service
public class TypeOfIncidentService {


    @Autowired
    TypeOfIncidentRepository typeOfIncidentRepository;

    public List<TypeOfIncident> findAll(){
        return typeOfIncidentRepository.findAll();
    }

    public Optional<TypeOfIncident> findById(Long type_id){
        return typeOfIncidentRepository.findById(type_id);
    }

    // Для методов Post и Put метод будет один

    public TypeOfIncident save(TypeOfIncident type_of_incident){
        return typeOfIncidentRepository.save(type_of_incident);
    }

    public void deleteById(Long type_id){
        typeOfIncidentRepository.deleteById(type_id);
    }




}
